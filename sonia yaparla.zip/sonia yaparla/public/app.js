const $ = (s) => document.querySelector(s);
let currentUser = null, categories = [], authMode = "login";

async function api(url, options = {}) {
  const response = await fetch(url, options);
  const data = response.headers.get("content-type")?.includes("application/json") ? await response.json() : null;
  if (!response.ok) throw new Error(data?.error || "Something went wrong.");
  return data;
}
function showMessage(el, msg) { el.textContent = msg || ""; }
function switchView(view) {
  ["dashboard","upload","categories"].forEach(v => $(`#${v}View`).classList.toggle("hidden", v !== view));
  document.querySelectorAll(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.view === view));
  $("#pageTitle").textContent = ({dashboard:"My documents",upload:"Upload document",categories:"Categories"})[view];
  if (view === "dashboard") loadDocuments();
  if (view === "categories") renderCategories();
}
document.querySelectorAll(".nav-item").forEach(b => b.addEventListener("click", () => switchView(b.dataset.view)));
$("#quickUpload").addEventListener("click", () => switchView("upload"));

document.querySelectorAll(".tab").forEach(b => b.addEventListener("click", () => {
  authMode = b.dataset.auth;
  document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t === b));
  $("#nameField").classList.toggle("hidden", authMode !== "register");
  $("#authSubmit").innerHTML = authMode === "login" ? 'Sign in to workspace <span>→</span>' : 'Create my account <span>→</span>';
  $("#authForm").elements.password.minLength = authMode === "register" ? 8 : 1;
  showMessage($("#authMessage"), "");
}));
$("#authForm").addEventListener("submit", async e => {
  e.preventDefault(); showMessage($("#authMessage"), "Please wait…");
  const body = Object.fromEntries(new FormData(e.target).entries());
  try {
    const data = await api(`/api/${authMode}`, {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
    currentUser = data.user; e.target.reset(); await enterApp();
  } catch(err) { showMessage($("#authMessage"), err.message); }
});
async function enterApp() {
  $("#authPanel").classList.add("hidden"); $("#appPanel").classList.remove("hidden"); $("#logoutBtn").classList.remove("hidden");
  $("#userName").textContent = currentUser.name; await loadCategories(); switchView("dashboard");
}
async function loadCategories() {
  categories = await api("/api/categories");
  $("#categoryCount").textContent = categories.length;
  $("#categoryFilter").innerHTML = '<option value="">All categories</option>' + categories.map(c=>`<option value="${c.category_id}">${escapeHtml(c.category_name)}</option>`).join("");
  $("#uploadCategory").innerHTML = '<option value="">Choose a category</option>' + categories.map(c=>`<option value="${c.category_id}">${escapeHtml(c.category_name)}</option>`).join("");
}
function escapeHtml(value) { return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
async function loadDocuments() {
  try {
    const params = new URLSearchParams({q:$("#searchInput").value,category:$("#categoryFilter").value});
    const docs = await api(`/api/documents?${params}`);
    $("#docCount").textContent = docs.length;
    $("#sharedCount").textContent = docs.filter(d=>d.user_id !== currentUser.user_id).length;
    $("#documentList").innerHTML = docs.length ? docs.map(d => {
      const owner = d.user_id === currentUser.user_id;
      const ext = (d.file_name.split(".").pop() || "FILE").slice(0,4).toUpperCase();
      return `<article class="doc-row"><div class="file-icon">${escapeHtml(ext)}</div><div class="doc-info"><strong>${escapeHtml(d.title)}</strong><small>${escapeHtml(d.category_name)} · ${escapeHtml(d.owner_name)} · ${new Date(d.upload_date).toLocaleDateString()}</small></div><div class="doc-actions"><button class="mini-btn" onclick="downloadDoc(${d.document_id})">↓ Download</button>${owner || currentUser.role==="admin" ? `<button class="mini-btn" onclick="openShare(${d.document_id})">↗ Access</button><button class="mini-btn" onclick="deleteDoc(${d.document_id})">Delete</button>` : ""}</div></article>`;
    }).join("") : '<div class="empty">No documents found. Upload your first document to begin.</div>';
  } catch(err) { $("#documentList").innerHTML = `<div class="empty">${escapeHtml(err.message)}</div>`; }
}
$("#searchInput").addEventListener("input", loadDocuments);
$("#categoryFilter").addEventListener("change", loadDocuments);
async function downloadDoc(id) {
  try {
    const response = await fetch(`/api/documents/${id}/download`);
    if (!response.ok) { const d=await response.json(); throw new Error(d.error); }
    const blob = await response.blob(), url = URL.createObjectURL(blob), a=document.createElement("a");
    a.href=url; a.download="document"; a.click(); URL.revokeObjectURL(url);
  } catch(e) { alert(e.message); }
}
async function deleteDoc(id) {
  if (!confirm("Delete this document permanently?")) return;
  try { await api(`/api/documents/${id}`,{method:"DELETE"}); loadDocuments(); } catch(e) { alert(e.message); }
}
$("#uploadForm").addEventListener("submit", async e => {
  e.preventDefault(); showMessage($("#uploadMessage"), "Uploading…");
  try {
    await api("/api/documents",{method:"POST",body:new FormData(e.target)});
    e.target.reset(); showMessage($("#uploadMessage"), "Document uploaded successfully."); await loadDocuments(); switchView("dashboard");
  } catch(err) { showMessage($("#uploadMessage"), err.message); }
});
$("#categoryForm").addEventListener("submit", async e => {
  e.preventDefault(); const body=Object.fromEntries(new FormData(e.target).entries());
  try { await api("/api/categories",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)}); e.target.reset(); showMessage($("#categoryMessage"),"Category added."); await loadCategories(); renderCategories(); }
  catch(err) { showMessage($("#categoryMessage"),err.message); }
});
function renderCategories() {
  $("#categoryList").innerHTML = categories.map(c=>`<div class="category-card"><strong>${escapeHtml(c.category_name)}</strong><p>${escapeHtml(c.description || "No description added.")}</p></div>`).join("");
}
async function openShare(id) {
  $("#shareForm").elements.document_id.value=id; $("#shareModal").classList.remove("hidden"); showMessage($("#shareMessage"),""); await loadAccess(id);
}
window.openShare = openShare;
async function loadAccess(id) {
  try {
    const rows=await api(`/api/documents/${id}/access`);
    $("#accessList").innerHTML=rows.length?`<p class="eyebrow">CURRENT ACCESS</p>`+rows.map(a=>`<div class="access-row"><div>${escapeHtml(a.name)}<small>${escapeHtml(a.email)} · ${escapeHtml(a.permission)}</small></div><button class="mini-btn" onclick="revokeAccess(${a.access_id},${id})">Revoke</button></div>`).join(""):'<p class="tiny">No one else has access yet.</p>';
  } catch(e) { $("#accessList").textContent=e.message; }
}
window.revokeAccess = async (accessId,docId) => { try { await api(`/api/access/${accessId}`,{method:"DELETE"}); await loadAccess(docId); } catch(e) { alert(e.message); } };
$("#shareForm").addEventListener("submit",async e=>{
  e.preventDefault(); const fd=new FormData(e.target), id=fd.get("document_id");
  try { const body={email:fd.get("email"),permission:fd.get("permission")}; await api(`/api/documents/${id}/access`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)}); showMessage($("#shareMessage"),"Access granted."); e.target.elements.email.value=""; await loadAccess(id); }
  catch(err) { showMessage($("#shareMessage"),err.message); }
});
$("#closeModal").addEventListener("click",()=>$("#shareModal").classList.add("hidden"));
$("#shareModal").addEventListener("click",e=>{if(e.target.id==="shareModal")$("#shareModal").classList.add("hidden");});
$("#logoutBtn").addEventListener("click",async()=>{await api("/api/logout",{method:"POST"});location.reload();});
(async()=>{try{const d=await api("/api/me");if(d.user){currentUser=d.user;await enterApp();}}catch{}})();
